-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 17, 2024 at 07:21 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perpustakaan`
--

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE `buku` (
  `ISBN` varchar(20) NOT NULL,
  `Judul` varchar(200) NOT NULL,
  `Jenis` varchar(10) NOT NULL,
  `Penulis` varchar(100) NOT NULL,
  `Penerbit` varchar(100) NOT NULL,
  `Tahun_terbit` varchar(10) NOT NULL,
  `Halaman` varchar(10) NOT NULL,
  `Rak` varchar(10) NOT NULL,
  `Stok` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`ISBN`, `Judul`, `Jenis`, `Penulis`, `Penerbit`, `Tahun_terbit`, `Halaman`, `Rak`, `Stok`) VALUES
('1', 'bobosiang', 'Fiksi', 'dimas', 'gramedia', '2024', '100', '5', '5'),
('2', 'Malam Indah', 'Fiksi', 'Ahmad Supardi', 'Gramedia', '2024', '120', '6', '2'),
('3', 'halaman awal', 'Fiksi', 'anisa nabila putri', 'gramedia', '2024', '60', '12', '8');

-- --------------------------------------------------------

--
-- Table structure for table `datadenda`
--

CREATE TABLE `datadenda` (
  `id_denda` int(200) NOT NULL,
  `nama_pengunjung` varchar(200) NOT NULL,
  `nama_pegawai` varchar(200) NOT NULL,
  `tgl_pengembalian` date NOT NULL,
  `telat_pengembalian` varchar(200) NOT NULL,
  `harga_denda` varchar(200) NOT NULL,
  `judul_buku` varchar(200) NOT NULL,
  `tglpinjam_sblmnya` date NOT NULL,
  `tglkembali_sblmnya` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `datadenda`
--

INSERT INTO `datadenda` (`id_denda`, `nama_pengunjung`, `nama_pegawai`, `tgl_pengembalian`, `telat_pengembalian`, `harga_denda`, `judul_buku`, `tglpinjam_sblmnya`, `tglkembali_sblmnya`) VALUES
(1, 'agfa', 'rafiq al qornain', '2024-06-27', '0 Hari', 'Rp0,00', 'bobosiang', '2024-06-09', '2024-06-27'),
(2, 'Pilih Nama Pengunjung', 'Pilih Nama Pegawai', '2024-06-30', '0 Hari', 'Rp0,00', 'mukti', '2024-06-11', '2024-06-29'),
(3, 'danar', 'ahmad', '2024-06-30', '0 Hari', 'Rp0,00', 'mukti', '2024-06-11', '2024-06-29'),
(4, 'danar', 'rafiq al qornain', '2024-06-13', '0 Hari', 'Rp0,00', 'danar', '2024-06-11', '2024-06-11'),
(5, 'agfa', 'ahmad', '2024-06-30', '0 Hari', 'Rp0,00', 'bobosiang', '2024-06-09', '2024-06-27'),
(6, 'danar', 'ahmad', '2024-06-28', '0 Hari', 'Rp0,00', 'danar', '2024-06-13', '2024-06-26'),
(7, 'mukti', 'rafiq', '2024-06-29', '0 Hari', 'Rp0,00', 'bobosiang', '2024-06-09', '2024-06-27'),
(8, 'mukti', 'rafiq', '2024-06-29', '0 Hari', 'Rp0,00', 'bobosiang', '2024-06-09', '2024-06-27'),
(9, 'danar', 'rafiq', '2024-06-30', '0 Hari', 'Rp0,00', 'danar', '2024-06-11', '2024-06-11'),
(10, 'danar', 'rafiq al qornain', '2024-07-03', '0 Hari', 'Rp0,00', 'mukti', '2024-06-11', '2024-06-29'),
(11, 'mukti', 'ahmad', '2024-06-30', '0 Hari', 'Rp0,00', 'mukti', '2024-06-11', '2024-06-29'),
(12, 'mukti', 'ahmad', '2024-06-30', '0 Hari', 'Rp0,00', 'bobosiang', '2024-06-09', '2024-06-27'),
(13, 'mukti', 'ahmad', '2024-06-30', '0 Hari', 'Rp0,00', 'danar', '2024-06-13', '2024-06-26'),
(14, 'danar', 'rafiq al qornain', '2024-06-30', '3 Hari', 'Rp150.000,00', 'bobosiang', '2024-06-09', '2024-06-27'),
(15, 'gunawan', 'rafiq al qornain', '2024-11-25', '0 Hari', 'Rp0,00', 'Malam Indah', '2024-11-17', '2024-11-25');

-- --------------------------------------------------------

--
-- Table structure for table `datapeminjaman`
--

CREATE TABLE `datapeminjaman` (
  `id` int(11) NOT NULL,
  `id_buku` varchar(20) NOT NULL,
  `judul` varchar(200) NOT NULL,
  `id_pengunjung` int(50) NOT NULL,
  `Nama_pengunjung` varchar(100) NOT NULL,
  `id_pustakawan` varchar(30) NOT NULL,
  `tanggal_pinjam` date NOT NULL,
  `tanggal_pengembalian` date NOT NULL,
  `tgl_input` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `datapeminjaman`
--

INSERT INTO `datapeminjaman` (`id`, `id_buku`, `judul`, `id_pengunjung`, `Nama_pengunjung`, `id_pustakawan`, `tanggal_pinjam`, `tanggal_pengembalian`, `tgl_input`) VALUES
(15, '3', 'halaman awal', 7, 'agfa', '0909', '2024-06-26', '2024-06-29', '2024-11-16 18:40:18'),
(16, '2', 'Malam Indah', 11, 'gunawan', '0909', '2024-11-17', '2024-11-23', '2024-11-16 18:40:18'),
(17, '1', 'bobosiang', 12, 'budi', '12', '2024-11-17', '2024-11-19', '2024-11-15 19:47:40'),
(18, '2', 'Malam Indah', 8, 'danu', '1', '2024-11-17', '2024-11-19', '2024-11-14 19:47:51');

-- --------------------------------------------------------

--
-- Table structure for table `datapengembalian`
--

CREATE TABLE `datapengembalian` (
  `id_peminjaman` varchar(100) NOT NULL,
  `nama_pengunjung` varchar(100) NOT NULL,
  `judul_buku` varchar(100) NOT NULL,
  `tanggal_peminjaman` date NOT NULL,
  `tanggal_pengembaliann` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `datapengembalian`
--

INSERT INTO `datapengembalian` (`id_peminjaman`, `nama_pengunjung`, `judul_buku`, `tanggal_peminjaman`, `tanggal_pengembaliann`) VALUES
('3', 'agfa', 'halaman awal', '2024-06-26', '2024-06-29'),
('3', 'agfa', 'halaman awal', '2024-06-26', '2024-06-29'),
('3', 'agfa', 'halaman awal', '2024-06-26', '2024-06-29'),
('3', 'agfa', 'halaman awal', '2024-06-26', '2024-06-29'),
('2', '11', 'Malam Indah', '2024-11-17', '2024-11-25');

-- --------------------------------------------------------

--
-- Table structure for table `datapengunjung`
--

CREATE TABLE `datapengunjung` (
  `id` int(50) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `usia` varchar(50) NOT NULL,
  `category_age` varchar(200) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `phone` int(50) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `datapengunjung`
--

INSERT INTO `datapengunjung` (`id`, `nama`, `usia`, `category_age`, `alamat`, `phone`, `tanggal`) VALUES
(5, 'danar', '20', 'dewasa', 'jl kemana?', 507, '2024-11-14 17:00:00'),
(6, 'mukti', '14', 'remaja', 'jl kemana aja yg penting sama kamu', 895655454, '2024-11-12 17:00:00'),
(8, 'danu', '6', 'anak-anak', 'jl rptra', 89123456, '2024-11-11 17:00:00'),
(9, 'hujan', '25', 'dewasa', 'jl wisman', 89651315, '2024-10-14 17:00:00'),
(10, 'louis', '15', 'remaja', 'jl kebo', 986465313, '2024-11-07 17:00:00'),
(11, 'gunawan', '7', 'anak-anak', 'jl kecapi', 89864321, '2024-10-31 17:00:00'),
(12, 'budi', '22', 'dewasa', 'jl kemang', 8956313, '2024-11-13 17:00:00'),
(13, 'Juan', '25', 'dewasa', 'jl harapan', 98465132, '2024-11-16 11:20:26');

-- --------------------------------------------------------

--
-- Table structure for table `pustakawan`
--

CREATE TABLE `pustakawan` (
  `kd_anggota` varchar(30) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `notelp` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pustakawan`
--

INSERT INTO `pustakawan` (`kd_anggota`, `nama`, `alamat`, `notelp`) VALUES
('12', 'rafiq', 'babelan', '089832463724'),
('0909', 'ahmad', 'bekasi', '089510167062'),
('1', 'rafiq al qornain', 'babelan city', '0656498321');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`ISBN`);

--
-- Indexes for table `datadenda`
--
ALTER TABLE `datadenda`
  ADD PRIMARY KEY (`id_denda`);

--
-- Indexes for table `datapeminjaman`
--
ALTER TABLE `datapeminjaman`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `datapengunjung`
--
ALTER TABLE `datapengunjung`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `datadenda`
--
ALTER TABLE `datadenda`
  MODIFY `id_denda` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `datapeminjaman`
--
ALTER TABLE `datapeminjaman`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `datapengunjung`
--
ALTER TABLE `datapengunjung`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
